import json
import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app import create_app  # noqa: E402
from liver_schema import DATA_PATH, FEATURE_COLUMNS, METRICS_PATH, MODEL_FILES, MODELS_DIR, TARGET  # noqa: E402

MODELS_EXIST = METRICS_PATH.exists() and all((MODELS_DIR / f).exists() for f in MODEL_FILES.values())
needs_models = pytest.mark.skipif(not MODELS_EXIST, reason="run python training/train_models.py first")

VALID = {"Age": 45, "Gender": "Male", "Total_Bilirubin": 1.2, "Direct_Bilirubin": 0.4,
         "Alkaline_Phosphotase": 210, "Alamine_Aminotransferase": 40, "Aspartate_Aminotransferase": 45,
         "Total_Protiens": 6.8, "Albumin": 3.4, "Albumin_and_Globulin_Ratio": 1.0}


@pytest.fixture()
def client():
    app = create_app()
    app.config["TESTING"] = True
    return app.test_client()


def test_schema_matches_csv():
    df = pd.read_csv(DATA_PATH)
    assert set(df.columns) == set(FEATURE_COLUMNS) | {TARGET}
    assert set(df[TARGET].unique()) == {1, 2}


@pytest.mark.parametrize("path", ["/", "/assessment", "/results", "/dashboard", "/about"])
def test_pages_load(client, path):
    r = client.get(path)
    assert r.status_code == 200
    assert b"not a medical" in r.data.lower() or b"not a diagnosis" in r.data.lower() or path == "/results"


def test_unknown_page_is_404(client):
    assert client.get("/nope").status_code == 404
    assert client.get("/api/nope").get_json()["ok"] is False


def test_health(client):
    r = client.get("/api/health")
    assert r.status_code == 200
    body = r.get_json()
    assert body["status"] == "ok" and "models_loaded" in body


@needs_models
def test_metrics_api_matches_file(client):
    body = client.get("/api/model-metrics").get_json()
    on_disk = json.loads(METRICS_PATH.read_text(encoding="utf-8"))
    assert body["ok"] is True
    assert set(body["models"]) == {"naive_bayes", "svm", "random_forest"}
    for k, m in on_disk["models"].items():
        for metric in ("accuracy", "precision", "recall", "f1"):
            assert body["models"][k][metric] == m[metric]


def test_metrics_api_missing_file_is_safe(tmp_path):
    app = create_app(models_dir=tmp_path, metrics_path=tmp_path / "metrics.json")
    r = app.test_client().get("/api/model-metrics")
    assert r.status_code == 503 and r.get_json()["ok"] is False


def test_predict_rejects_non_json(client):
    r = client.post("/api/predict", data="hello", content_type="text/plain")
    assert r.status_code == 400


def test_predict_validation_errors(client):
    bad = dict(VALID, Gender="Other", Age="abc", Albumin=-1)
    del bad["Total_Bilirubin"]
    r = client.post("/api/predict", json=bad)
    body = r.get_json()
    assert r.status_code == 400 and body["ok"] is False
    assert set(body["field_errors"]) == {"Gender", "Age", "Albumin", "Total_Bilirubin"}
    assert "Traceback" not in json.dumps(body)


def test_predict_rejects_fractional_int_field(client):
    r = client.post("/api/predict", json=dict(VALID, Age=45.5))
    assert r.status_code == 400 and "Age" in r.get_json()["field_errors"]


def test_predict_missing_models_is_safe(tmp_path):
    app = create_app(models_dir=tmp_path, metrics_path=tmp_path / "metrics.json")
    r = app.test_client().post("/api/predict", json=VALID)
    assert r.status_code == 503 and r.get_json()["ok"] is False


@needs_models
def test_predict_success(client):
    r = client.post("/api/predict", json=VALID)
    body = r.get_json()
    assert r.status_code == 200 and body["ok"] is True
    assert [p["key"] for p in body["predictions"]] == ["naive_bayes", "svm", "random_forest"]
    for p in body["predictions"]:
        assert p["label_code"] in (1, 2)
        assert abs(sum(p["probabilities"].values()) - 1) < 1e-6
    assert body["total_models"] == 3


@needs_models
def test_predict_optional_ratio_blank_and_string_numbers(client):
    payload = {k: str(v) for k, v in VALID.items()}
    payload["Albumin_and_Globulin_Ratio"] = ""
    body = client.post("/api/predict", json=payload).get_json()
    assert body["ok"] is True and body["imputed"] == ["Albumin_and_Globulin_Ratio"]
