// Renders the prediction returned by /api/predict (held only in this tab's sessionStorage).
(function () {
  var data = null;
  try { data = JSON.parse(sessionStorage.getItem("liverAssessmentResult")); } catch (e) { data = null; }
  var empty = document.getElementById("results-empty");
  var content = document.getElementById("results-content");
  if (!data || !data.ok || !data.predictions) { empty.hidden = false; return; }
  content.hidden = false;

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }

  var summary = document.getElementById("results-summary");
  var votes = data.liver_patient_votes, total = data.total_models;
  var headline = votes === total ? "All " + total + " models classify this profile as “" + data.positive_class_label + "”."
    : votes === 0 ? "None of the " + total + " models classify this profile as “" + data.positive_class_label + "”."
    : votes + " of " + total + " models classify this profile as “" + data.positive_class_label + "”.";
  summary.appendChild(el("p", "big", headline));
  summary.appendChild(el("p", "", votes > 0 && votes < total
    ? "The models disagree, which is common with a small dataset. Treat this as a prompt for professional advice, not an answer."
    : "This is a model-based classification from the dataset, not a medical diagnosis."));

  var warnings = [];
  if (data.imputed && data.imputed.length) {
    warnings.push("Not provided, so the training median was used: " + data.imputed.map(function (n) { return data.labels[n]; }).join(", ") + ".");
  }
  if (data.out_of_dataset_range && data.out_of_dataset_range.length) {
    warnings.push("Outside the range seen in the dataset, so predictions may be unreliable: " + data.out_of_dataset_range.map(function (n) { return data.labels[n]; }).join(", ") + ".");
  }
  if (warnings.length) {
    var w = document.getElementById("results-warnings");
    w.textContent = warnings.join(" ");
    w.hidden = false;
  }

  var list = document.getElementById("model-results");
  data.predictions.forEach(function (p) {
    var row = el("article", "model-row");
    var head = el("div", "model-head");
    head.appendChild(el("h3", "", p.name));
    head.appendChild(el("span", "chip " + (p.is_liver_patient ? "positive" : "negative"), p.label));
    row.appendChild(head);
    var pct = p.probability_liver_patient * 100;
    var meter = el("div", "meter");
    meter.setAttribute("role", "img");
    meter.setAttribute("aria-label", p.name + " probability of liver patient class: " + pct.toFixed(1) + " percent");
    var fill = el("div", "meter-fill");
    meter.appendChild(fill);
    row.appendChild(meter);
    row.appendChild(el("p", "meter-label", "Probability of “" + data.positive_class_label + "”: " + pct.toFixed(1) + "%"));
    list.appendChild(row);
    window.requestAnimationFrame(function () { fill.style.width = pct.toFixed(1) + "%"; });
  });

  var vals = document.getElementById("submitted-values");
  Object.keys(data.labels).forEach(function (name) {
    var v = data.input[name];
    vals.appendChild(el("dt", "", data.labels[name]));
    vals.appendChild(el("dd", "", v === null || v === undefined ? "Not provided" : String(v)));
  });

  document.getElementById("new-assessment").addEventListener("click", function () {
    try { sessionStorage.removeItem("liverAssessmentResult"); } catch (e) { /* ignore */ }
  });
})();
