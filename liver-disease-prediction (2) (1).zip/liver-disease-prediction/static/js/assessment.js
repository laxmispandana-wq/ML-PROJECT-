// Multi-step assessment form: validation, review, and prediction request.
(function () {
  var form = document.getElementById("assessment-form");
  var steps = Array.prototype.slice.call(form.querySelectorAll(".step"));
  var reviewStep = parseInt(form.dataset.reviewStep, 10);
  var btnPrev = document.getElementById("btn-prev");
  var btnNext = document.getElementById("btn-next");
  var btnSubmit = document.getElementById("btn-submit");
  var alertBox = document.getElementById("form-alert");
  var progressText = document.getElementById("progress-text");
  var progressFill = document.getElementById("progress-fill");
  var progressItems = document.querySelectorAll("[data-progress-step]");
  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var current = 1;

  function stepEl(n) { return form.querySelector('.step[data-step="' + n + '"]'); }
  function fieldWrap(name) { return form.querySelector('[data-field="' + name + '"]'); }

  function setError(name, msg) {
    var wrap = fieldWrap(name);
    var err = document.getElementById(name + "-error");
    var input = form.querySelector('input[name="' + name + '"]');
    if (err) { err.textContent = msg || ""; err.hidden = !msg; }
    wrap.querySelectorAll("input").forEach(function (i) {
      if (msg) i.setAttribute("aria-invalid", "true"); else i.removeAttribute("aria-invalid");
    });
    return input;
  }

  function fieldNames(n) {
    return Array.prototype.map.call(stepEl(n).querySelectorAll("[data-field]"), function (w) { return w.dataset.field; });
  }

  function validateField(name) {
    var wrap = fieldWrap(name);
    var radios = wrap.querySelectorAll('input[type="radio"]');
    if (radios.length) {
      var checked = wrap.querySelector('input[type="radio"]:checked');
      if (!checked) { setError(name, "Please choose an option."); return false; }
      setError(name, ""); return true;
    }
    var input = wrap.querySelector("input");
    var raw = input.value.trim();
    var label = input.dataset.label;
    if (raw === "") {
      if (input.required) { setError(name, label + " is required."); return false; }
      setError(name, ""); return true;
    }
    var num = Number(raw);
    var min = Number(input.min), max = Number(input.max);
    if (!isFinite(num)) { setError(name, label + " must be a number."); return false; }
    if (num < min || num > max) { setError(name, label + " must be between " + min + " and " + max + "."); return false; }
    if (input.dataset.type === "int" && !Number.isInteger(num)) { setError(name, label + " must be a whole number."); return false; }
    setError(name, ""); return true;
  }

  function validateStep(n) {
    var firstBad = null;
    fieldNames(n).forEach(function (name) {
      if (!validateField(name) && !firstBad) firstBad = name;
    });
    if (firstBad) {
      var el = form.querySelector('[name="' + firstBad + '"]');
      if (el) el.focus();
      return false;
    }
    return true;
  }

  function collect() {
    var data = {};
    form.querySelectorAll("[data-field]").forEach(function (w) {
      var name = w.dataset.field;
      var radio = w.querySelector('input[type="radio"]');
      if (radio) {
        var c = w.querySelector('input[type="radio"]:checked');
        data[name] = c ? c.value : "";
      } else {
        data[name] = w.querySelector("input").value.trim();
      }
    });
    return data;
  }

  function buildReview() {
    var list = document.getElementById("review-list");
    list.textContent = "";
    var data = collect();
    form.querySelectorAll("[data-field]").forEach(function (w) {
      var name = w.dataset.field;
      var labelEl = w.querySelector("label:not(.radio)") || w.querySelector("legend");
      var label = labelEl.childNodes[0].textContent.trim();
      var dt = document.createElement("dt"); dt.textContent = label;
      var dd = document.createElement("dd");
      dd.textContent = data[name] === "" ? "Not provided (training median used)" : data[name];
      list.appendChild(dt); list.appendChild(dd);
    });
  }

  function show(n) {
    current = n;
    steps.forEach(function (s) { s.hidden = parseInt(s.dataset.step, 10) !== n; });
    if (n === reviewStep) buildReview();
    btnPrev.disabled = n === 1;
    btnNext.hidden = n === reviewStep;
    btnSubmit.hidden = n !== reviewStep;
    progressText.textContent = "Step " + n + " of " + reviewStep;
    progressFill.style.width = ((n - 1) / (reviewStep - 1) * 100) + "%";
    progressItems.forEach(function (li) {
      if (parseInt(li.dataset.progressStep, 10) === n) li.setAttribute("aria-current", "step");
      else li.removeAttribute("aria-current");
    });
    var el = stepEl(n);
    el.tabIndex = -1;
    el.focus({ preventScroll: true });
    form.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "start" });
  }

  function showAlert(msg) { alertBox.textContent = msg; alertBox.hidden = !msg; }

  btnNext.addEventListener("click", function () { if (validateStep(current)) show(current + 1); });
  btnPrev.addEventListener("click", function () { showAlert(""); show(current - 1); });
  form.querySelectorAll("input").forEach(function (i) {
    i.addEventListener("input", function () { var w = i.closest("[data-field]"); if (w) setError(w.dataset.field, ""); });
    i.addEventListener("change", function () { var w = i.closest("[data-field]"); if (w) setError(w.dataset.field, ""); });
  });

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (current !== reviewStep) { btnNext.click(); return; }
    for (var n = 1; n < reviewStep; n++) {
      if (!validateStep(n)) { show(n); return; }
    }
    showAlert("");
    btnSubmit.disabled = true;
    btnSubmit.textContent = "Predicting…";
    fetch(form.dataset.predictUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify(collect())
    }).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (body) { return { res: res, body: body }; });
    }).then(function (r) {
      if (r.res.ok && r.body.ok) {
        try { sessionStorage.setItem("liverAssessmentResult", JSON.stringify(r.body)); } catch (err) { /* storage unavailable */ }
        window.location.assign(form.dataset.resultsUrl);
        return;
      }
      if (r.body.field_errors) {
        var first = null;
        Object.keys(r.body.field_errors).forEach(function (name) {
          if (fieldWrap(name)) { setError(name, r.body.field_errors[name]); if (!first) first = name; }
        });
        if (first) { show(parseInt(fieldWrap(first).closest(".step").dataset.step, 10)); }
      }
      showAlert(r.body.error || "The prediction could not be completed. Please try again.");
      btnSubmit.disabled = false; btnSubmit.textContent = "Submit for prediction";
    }).catch(function () {
      showAlert("Could not reach the server. Please check your connection and try again.");
      btnSubmit.disabled = false; btnSubmit.textContent = "Submit for prediction";
    });
  });

  show(1);
})();
