// Loads real metrics from the backend and draws the comparison chart, table and confusion matrices.
(function () {
  var root = document.getElementById("dashboard-root");
  var errorBox = document.getElementById("dash-error");
  var content = document.getElementById("dash-content");

  function el(tag, text, cls) {
    var n = document.createElement(tag);
    if (text !== undefined) n.textContent = text;
    if (cls) n.className = cls;
    return n;
  }
  function pct(v) { return (v * 100).toFixed(1) + "%"; }

  fetch(root.dataset.metricsUrl, { headers: { "Accept": "application/json" } })
    .then(function (res) { return res.json().then(function (b) { return { ok: res.ok, body: b }; }); })
    .then(function (r) {
      if (!r.ok || !r.body.ok) throw new Error(r.body.error || "Metrics unavailable.");
      render(r.body);
    })
    .catch(function (err) {
      errorBox.textContent = err.message || "Metrics could not be loaded.";
      errorBox.hidden = false;
    });

  function render(m) {
    var keys = Object.keys(m.models);
    var metrics = [["accuracy", "Accuracy"], ["precision", "Precision"], ["recall", "Recall"], ["f1", "F1-score"]];
    content.hidden = false;

    var n = m.split.n_test, tc = m.split.test_class_counts;
    document.getElementById("dash-context").textContent =
      "Test set: " + n + " rows (" + tc["1"] + " " + m.target_mapping["1"].toLowerCase() + ", " + tc["2"] + " " + m.target_mapping["2"].toLowerCase() +
      "). Always predicting the majority class would give " + pct(m.majority_baseline_accuracy) + " accuracy, so read accuracy alongside recall and precision.";

    // Table
    var table = document.getElementById("metrics-table");
    var thead = el("thead"), hr = el("tr");
    hr.appendChild(el("th", "Model"));
    metrics.forEach(function (x) { hr.appendChild(el("th", x[1])); });
    thead.appendChild(hr); table.appendChild(thead);
    var tbody = el("tbody");
    keys.forEach(function (k) {
      var tr = el("tr"); tr.appendChild(el("td", m.models[k].name));
      metrics.forEach(function (x) { tr.appendChild(el("td", pct(m.models[k][x[0]]))); });
      tbody.appendChild(tr);
    });
    table.appendChild(tbody);

    // Confusion matrices
    var grid = document.getElementById("cm-grid");
    keys.forEach(function (k) {
      var cm = m.models[k].confusion_matrix;
      var box = el("div", undefined, "cm");
      box.appendChild(el("h3", m.models[k].name));
      var t = el("table");
      var h = el("tr"); h.appendChild(el("th", "Actual ↓ / Predicted →"));
      cm.label_names.forEach(function (nm) { h.appendChild(el("th", nm)); });
      t.appendChild(h);
      cm.matrix.forEach(function (row, i) {
        var tr = el("tr"); tr.appendChild(el("th", cm.label_names[i]));
        row.forEach(function (v, j) { tr.appendChild(el("td", String(v), i === j ? "cm-correct" : "cm-wrong")); });
        t.appendChild(tr);
      });
      box.appendChild(t); grid.appendChild(box);
    });

    // Chart
    if (typeof Chart === "undefined") {
      errorBox.textContent = "The chart library could not be loaded (check your connection). The table below shows the same data.";
      errorBox.hidden = false;
      return;
    }
    var css = getComputedStyle(document.documentElement);
    var forest = css.getPropertyValue("--forest").trim(), terra = css.getPropertyValue("--terracotta").trim(),
        sage = css.getPropertyValue("--sage").trim(), ink = forest;
    var styles = [
      { backgroundColor: forest, borderColor: forest },
      { backgroundColor: terra, borderColor: terra },
      { backgroundColor: sage, borderColor: forest },
      { backgroundColor: forest + "88", borderColor: forest }
    ];
    var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    Chart.defaults.font.family = css.getPropertyValue("--sans").trim();
    Chart.defaults.color = ink;
    new Chart(document.getElementById("metrics-chart"), {
      type: "bar",
      data: {
        labels: keys.map(function (k) { return m.models[k].name; }),
        datasets: metrics.map(function (x, i) {
          return Object.assign({ label: x[1], borderWidth: 1.5, data: keys.map(function (k) { return m.models[k][x[0]] * 100; }) }, styles[i]);
        })
      },
      options: {
        responsive: true, maintainAspectRatio: false, animation: reduce ? false : undefined,
        scales: {
          y: { min: 0, max: 100, ticks: { callback: function (v) { return v + "%"; } }, grid: { color: "#315B4B22" } },
          x: { grid: { display: false } }
        },
        plugins: { tooltip: { callbacks: { label: function (c) { return c.dataset.label + ": " + c.parsed.y.toFixed(1) + "%"; } } } }
      }
    });
  }
})();
