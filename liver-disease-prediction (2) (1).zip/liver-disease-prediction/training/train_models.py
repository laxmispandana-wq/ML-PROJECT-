"""Train Naive Bayes, SVM and Random Forest on the Indian Liver Patient CSV.

Run from the project root:  python training/train_models.py
Writes models/*_pipeline.pkl and models/metrics.json.
"""
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, StandardScaler
from sklearn.svm import SVC

from liver_schema import (CATEGORICAL_FEATURES, CLASS_LABELS, DATA_PATH, FEATURE_COLUMNS,
                          GENDER_VALUES, LOG_FEATURES, METRICS_PATH, MODEL_FILES, MODEL_NAMES, MODELS_DIR,
                          NUMERIC_FEATURES, POSITIVE_CLASS, TARGET)

RANDOM_STATE = 42
TEST_SIZE = 0.20


def load_and_validate(path=DATA_PATH):
    df = pd.read_csv(path)
    expected = set(FEATURE_COLUMNS) | {TARGET}
    if set(df.columns) != expected:
        raise ValueError(f"Unexpected columns. Missing: {expected - set(df.columns)}; extra: {set(df.columns) - expected}")
    if not set(df[TARGET].unique()) <= set(CLASS_LABELS):
        raise ValueError(f"Unexpected target values: {sorted(df[TARGET].unique())}")
    if not set(df["Gender"].unique()) <= set(GENDER_VALUES):
        raise ValueError(f"Unexpected Gender values: {sorted(df['Gender'].unique())}")
    return df


def build_preprocessor():
    plain = [c for c in NUMERIC_FEATURES if c not in LOG_FEATURES]
    numeric = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())])
    logged = Pipeline([("imputer", SimpleImputer(strategy="median")),
                       ("log1p", FunctionTransformer(np.log1p)), ("scaler", StandardScaler())])
    categorical = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(categories=[GENDER_VALUES], handle_unknown="ignore", sparse_output=False)),
    ])
    return ColumnTransformer([("num", numeric, plain), ("log", logged, LOG_FEATURES),
                              ("cat", categorical, CATEGORICAL_FEATURES)])


def build_models():
    estimators = {
        "naive_bayes": GaussianNB(),
        "svm": SVC(kernel="rbf", C=1.0, gamma="scale", probability=True,
                   class_weight="balanced", random_state=RANDOM_STATE),
        "random_forest": RandomForestClassifier(n_estimators=300, class_weight="balanced",
                                                random_state=RANDOM_STATE, n_jobs=1),
    }
    return {k: Pipeline([("preprocess", build_preprocessor()), ("model", est)]) for k, est in estimators.items()}


def main():
    df = load_and_validate()
    rows_raw = len(df)
    missing = {c: int(n) for c, n in df.isna().sum().items() if n}
    df = df.drop_duplicates().reset_index(drop=True)  # avoid identical rows in both train and test
    X, y = df[FEATURE_COLUMNS], df[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=y)

    labels = sorted(CLASS_LABELS)
    results = {}
    MODELS_DIR.mkdir(exist_ok=True)
    for key, pipe in build_models().items():
        pipe.fit(X_train, y_train)  # imputer/scaler/encoder are fitted on training data only
        pred = pipe.predict(X_test)
        kw = dict(pos_label=POSITIVE_CLASS, zero_division=0)
        results[key] = {
            "name": MODEL_NAMES[key],
            "file": MODEL_FILES[key],
            "accuracy": accuracy_score(y_test, pred),
            "precision": precision_score(y_test, pred, **kw),
            "recall": recall_score(y_test, pred, **kw),
            "f1": f1_score(y_test, pred, **kw),
            "confusion_matrix": {
                "labels": labels,
                "label_names": [CLASS_LABELS[c] for c in labels],
                "matrix": confusion_matrix(y_test, pred, labels=labels).tolist(),
            },
            "hyperparameters": {k: v for k, v in pipe.named_steps["model"].get_params().items()
                                if k in ("n_estimators", "kernel", "C", "gamma", "class_weight", "probability", "var_smoothing")},
        }
        joblib.dump(pipe, MODELS_DIR / MODEL_FILES[key])
        print(f"{MODEL_NAMES[key]:32s} acc={results[key]['accuracy']:.4f} prec={results[key]['precision']:.4f} "
              f"rec={results[key]['recall']:.4f} f1={results[key]['f1']:.4f}")

    counts = lambda s: {str(k): int(v) for k, v in sorted(s.value_counts().items())}
    metrics = {
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "sklearn_version": sklearn.__version__,
        "random_state": RANDOM_STATE,
        "test_size": TEST_SIZE,
        "positive_class": POSITIVE_CLASS,
        "target_mapping": {str(k): v for k, v in CLASS_LABELS.items()},
        "dataset": {
            "file": DATA_PATH.name,
            "rows_raw": rows_raw,
            "duplicates_removed": rows_raw - len(df),
            "rows_used": len(df),
            "n_features": len(FEATURE_COLUMNS),
            "features": FEATURE_COLUMNS,
            "missing_values": missing,
            "class_counts": counts(y),
            "gender_counts": {k: int(v) for k, v in df["Gender"].value_counts().items()},
            "feature_summary": {c: {"min": float(df[c].min()), "median": float(df[c].median()), "max": float(df[c].max())}
                                for c in NUMERIC_FEATURES},
        },
        "split": {"n_train": len(X_train), "n_test": len(X_test),
                  "train_class_counts": counts(y_train), "test_class_counts": counts(y_test)},
        "majority_baseline_accuracy": float(y_test.value_counts(normalize=True).max()),
        "models": results,
    }
    METRICS_PATH.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(f"Saved pipelines and metrics to {MODELS_DIR}")


if __name__ == "__main__":
    main()
