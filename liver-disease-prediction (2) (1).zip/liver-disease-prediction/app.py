"""Flask app for the Liver Disease Prediction educational project."""
import json
import logging
import math
import os

import joblib
import pandas as pd
from flask import Flask, jsonify, render_template, request

from liver_schema import (CLASS_LABELS, DISCLAIMER, FEATURE_COLUMNS, FIELDS, METRICS_PATH,
                          MODEL_FILES, MODEL_KEYS, MODEL_NAMES, MODELS_DIR, POSITIVE_CLASS,
                          STEP_TITLES)

log = logging.getLogger("liver-app")
FIELD_MAP = {f["name"]: f for f in FIELDS}

CSP = ("default-src 'self'; script-src 'self' https://cdnjs.cloudflare.com; "
       "style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; "
       "img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'")


class ModelStore:
    """Loads saved pipelines and metrics lazily; never raises to the caller."""

    def __init__(self, models_dir, metrics_path):
        self.models_dir, self.metrics_path = models_dir, metrics_path
        self.pipelines, self.metrics = {}, None

    def missing_files(self):
        return [f for f in MODEL_FILES.values() if not (self.models_dir / f).exists()]

    def load(self):
        if not self.pipelines and not self.missing_files():
            try:
                self.pipelines = {k: joblib.load(self.models_dir / MODEL_FILES[k]) for k in MODEL_KEYS}
            except Exception:
                log.exception("Could not load model pipelines")
                self.pipelines = {}
        return self.pipelines

    def load_metrics(self):
        if self.metrics is None and self.metrics_path.exists():
            try:
                self.metrics = json.loads(self.metrics_path.read_text(encoding="utf-8"))
            except Exception:
                log.exception("Could not read metrics file")
        return self.metrics


def validate_input(payload):
    """Return (clean_values, field_errors). Blank optional fields become None."""
    if not isinstance(payload, dict):
        return None, {"_": "Request body must be a JSON object."}
    clean, errors = {}, {}
    for f in FIELDS:
        name, raw = f["name"], payload.get(f["name"])
        blank = raw is None or (isinstance(raw, str) and raw.strip() == "")
        if blank:
            if f["required"]:
                errors[name] = f"{f['label']} is required."
            else:
                clean[name] = None
            continue
        if f["type"] == "category":
            value = str(raw).strip().capitalize()
            if value not in f["options"]:
                errors[name] = f"{f['label']} must be one of: {', '.join(f['options'])}."
            else:
                clean[name] = value
            continue
        if isinstance(raw, bool):
            errors[name] = f"{f['label']} must be a number."
            continue
        try:
            num = float(raw)
        except (TypeError, ValueError):
            errors[name] = f"{f['label']} must be a number."
            continue
        if not math.isfinite(num):
            errors[name] = f"{f['label']} must be a finite number."
        elif not f["hard_min"] <= num <= f["hard_max"]:
            errors[name] = f"{f['label']} must be between {f['hard_min']} and {f['hard_max']}."
        elif f["type"] == "int" and num != int(num):
            errors[name] = f"{f['label']} must be a whole number."
        else:
            clean[name] = int(num) if f["type"] == "int" else num
    return clean, errors


def create_app(models_dir=MODELS_DIR, metrics_path=METRICS_PATH):
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "")  # unused (no sessions); env-driven if ever needed
    app.config["MAX_CONTENT_LENGTH"] = 16 * 1024
    app.json.sort_keys = False  # keep model order: Naive Bayes, SVM, Random Forest
    store = ModelStore(models_dir, metrics_path)

    def dataset_ranges():
        m = store.load_metrics()
        return m["dataset"]["feature_summary"] if m else {}

    @app.after_request
    def secure(resp):
        resp.headers.setdefault("Content-Security-Policy", CSP)
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("Referrer-Policy", "no-referrer")
        if request.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    def page(template, **ctx):
        return render_template(template, disclaimer=DISCLAIMER, **ctx)

    @app.route("/")
    def index():
        m = store.load_metrics()
        return page("index.html", active="home", metrics=m, model_names=MODEL_NAMES, class_labels=CLASS_LABELS)

    @app.route("/assessment")
    def assessment():
        steps = [{"n": n, "title": STEP_TITLES[n][0], "intro": STEP_TITLES[n][1],
                  "fields": [f for f in FIELDS if f["step_group"] == n]} for n in sorted(STEP_TITLES)]
        return page("assessment.html", active="assessment", steps=steps, ranges=dataset_ranges())

    @app.route("/results")
    def results():
        return page("results.html", active="results")

    @app.route("/dashboard")
    def dashboard():
        return page("dashboard.html", active="dashboard")

    @app.route("/about")
    def about():
        return page("about.html", active="about", metrics=store.load_metrics(), model_names=MODEL_NAMES)

    @app.get("/api/health")
    def health():
        return jsonify(status="ok", models_loaded=bool(store.load()),
                       missing_model_files=store.missing_files(),
                       metrics_available=store.load_metrics() is not None)

    @app.get("/api/model-metrics")
    def model_metrics():
        m = store.load_metrics()
        if m is None:
            return jsonify(ok=False, error="Metrics file not found. Run: python training/train_models.py"), 503
        return jsonify(ok=True, **m)

    @app.post("/api/predict")
    def predict():
        payload = request.get_json(silent=True)
        clean, errors = validate_input(payload)
        if errors:
            return jsonify(ok=False, error="Please correct the highlighted fields.", field_errors=errors), 400
        pipelines = store.load()
        if not pipelines:
            return jsonify(ok=False, error="Trained models are not available. Run: python training/train_models.py"), 503
        try:
            row = pd.DataFrame([clean], columns=FEATURE_COLUMNS)
            predictions = []
            for key in MODEL_KEYS:
                pipe = pipelines[key]
                code = int(pipe.predict(row)[0])
                proba = dict(zip((int(c) for c in pipe.classes_), (float(p) for p in pipe.predict_proba(row)[0])))
                predictions.append({
                    "key": key, "name": MODEL_NAMES[key], "label_code": code, "label": CLASS_LABELS[code],
                    "is_liver_patient": code == POSITIVE_CLASS,
                    "probabilities": {str(c): p for c, p in proba.items()},
                    "probability_liver_patient": proba[POSITIVE_CLASS],
                })
        except Exception:
            log.exception("Prediction failed")
            return jsonify(ok=False, error="The prediction could not be completed. Please check your values and try again."), 500

        ranges = dataset_ranges()
        out_of_range = [n for n, v in clean.items()
                        if v is not None and n in ranges and not ranges[n]["min"] <= v <= ranges[n]["max"]]
        return jsonify(ok=True, input=clean, labels={f['name']: f['label'] for f in FIELDS},
                       imputed=[n for n, v in clean.items() if v is None],
                       out_of_dataset_range=out_of_range,
                       predictions=predictions,
                       liver_patient_votes=sum(p["is_liver_patient"] for p in predictions),
                       total_models=len(predictions),
                       positive_class_label=CLASS_LABELS[POSITIVE_CLASS],
                       disclaimer=DISCLAIMER)

    @app.errorhandler(404)
    def not_found(_):
        if request.path.startswith("/api/"):
            return jsonify(ok=False, error="Not found."), 404
        return page("error.html", active="", code=404, message="That page could not be found."), 404

    @app.errorhandler(405)
    def bad_method(_):
        return jsonify(ok=False, error="Method not allowed."), 405

    @app.errorhandler(413)
    def too_large(_):
        return jsonify(ok=False, error="Request too large."), 413

    @app.errorhandler(500)
    def server_error(_):
        if request.path.startswith("/api/"):
            return jsonify(ok=False, error="Unexpected server error."), 500
        return page("error.html", active="", code=500, message="Something went wrong on our side."), 500

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT", 5000)),
            debug=os.environ.get("FLASK_DEBUG") == "1")
