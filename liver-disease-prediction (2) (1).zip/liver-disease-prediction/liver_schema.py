"""Single source of truth for dataset columns, labels and form fields."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data" / "indian_liver_patient.csv"
MODELS_DIR = ROOT / "models"
METRICS_PATH = MODELS_DIR / "metrics.json"

TARGET = "Dataset"
NUMERIC_FEATURES = [
    "Age",
    "Total_Bilirubin",
    "Direct_Bilirubin",
    "Alkaline_Phosphotase",
    "Alamine_Aminotransferase",
    "Aspartate_Aminotransferase",
    "Total_Protiens",
    "Albumin",
    "Albumin_and_Globulin_Ratio",
]
# Strongly right-skewed lab values (max far above the 75th percentile): log1p before scaling.
LOG_FEATURES = ["Total_Bilirubin", "Direct_Bilirubin", "Alkaline_Phosphotase",
                "Alamine_Aminotransferase", "Aspartate_Aminotransferase"]
CATEGORICAL_FEATURES = ["Gender"]
GENDER_VALUES = ["Female", "Male"]
FEATURE_COLUMNS = ["Age", "Gender"] + NUMERIC_FEATURES[1:]

# Target labels verified from the CSV: only 1 (416 rows) and 2 (167 rows) occur.
# Following the UCI ILPD documentation, 1 = liver patient, 2 = non-liver patient.
POSITIVE_CLASS = 1
CLASS_LABELS = {1: "Liver patient", 2: "Not a liver patient"}

MODEL_KEYS = ["naive_bayes", "svm", "random_forest"]
MODEL_NAMES = {
    "naive_bayes": "Naive Bayes",
    "svm": "Support Vector Machine (SVM)",
    "random_forest": "Random Forest",
}
MODEL_FILES = {k: f"{k}_pipeline.pkl" for k in MODEL_KEYS}

# Form / validation schema. `hard_min`/`hard_max` are plausibility limits for
# input validation; the observed dataset range is shown separately from metrics.json.
FIELDS = [
    {"name": "Age", "label": "Age", "type": "int", "step_group": 1,
     "hard_min": 1, "hard_max": 120, "step": "1", "required": True,
     "help": "Age in years."},
    {"name": "Gender", "label": "Gender", "type": "category", "step_group": 1,
     "options": GENDER_VALUES, "required": True,
     "help": "As recorded in the dataset (Female / Male)."},
    {"name": "Total_Bilirubin", "label": "Total Bilirubin", "type": "float", "step_group": 2,
     "hard_min": 0, "hard_max": 100, "step": "0.1", "required": True,
     "help": "Total bilirubin from the liver function test."},
    {"name": "Direct_Bilirubin", "label": "Direct Bilirubin", "type": "float", "step_group": 2,
     "hard_min": 0, "hard_max": 50, "step": "0.1", "required": True,
     "help": "Direct (conjugated) bilirubin."},
    {"name": "Alkaline_Phosphotase", "label": "Alkaline Phosphatase (ALP)", "type": "int", "step_group": 3,
     "hard_min": 0, "hard_max": 5000, "step": "1", "required": True,
     "help": "Alkaline phosphatase enzyme level."},
    {"name": "Alamine_Aminotransferase", "label": "Alanine Aminotransferase (ALT)", "type": "int", "step_group": 3,
     "hard_min": 0, "hard_max": 5000, "step": "1", "required": True,
     "help": "ALT / SGPT enzyme level."},
    {"name": "Aspartate_Aminotransferase", "label": "Aspartate Aminotransferase (AST)", "type": "int", "step_group": 3,
     "hard_min": 0, "hard_max": 10000, "step": "1", "required": True,
     "help": "AST / SGOT enzyme level."},
    {"name": "Total_Protiens", "label": "Total Proteins", "type": "float", "step_group": 4,
     "hard_min": 0, "hard_max": 15, "step": "0.1", "required": True,
     "help": "Total protein level."},
    {"name": "Albumin", "label": "Albumin", "type": "float", "step_group": 4,
     "hard_min": 0, "hard_max": 10, "step": "0.1", "required": True,
     "help": "Serum albumin level."},
    {"name": "Albumin_and_Globulin_Ratio", "label": "Albumin / Globulin Ratio", "type": "float", "step_group": 4,
     "hard_min": 0, "hard_max": 10, "step": "0.01", "required": False,
     "help": "Optional. If left blank, the training-set median is used (the dataset itself has 4 blank values here)."},
]
STEP_TITLES = {
    1: ("Basic details", "Age and gender, as recorded in the dataset."),
    2: ("Bilirubin", "Two bilirubin measurements from the liver function test."),
    3: ("Liver enzymes", "Three enzyme measurements."),
    4: ("Proteins", "Protein measurements. The ratio is optional."),
}

DISCLAIMER = (
    "This application is an educational machine learning project. It provides "
    "model-based risk classification from the supplied dataset and is not a medical "
    "diagnosis. It should not replace professional medical advice or consultation "
    "with a qualified healthcare professional."
)

assert [f["name"] for f in FIELDS] == FEATURE_COLUMNS
